BÁO CÁO NIÊN LUẬN MMT&TT
-Thành viên nhóm:
	+ Lê Tấn Luận (B1807573)
	+ Phạm Văn Phi Dương (B1807625)
	+ Nguyễn Tiến Đạt (B1807627)
- Đề tài 2: Xây dựng ứng dụng hỗ trợ dạy và học trực tuyến.
- Quá trình quay video demo chưa hoàn toàn chỉnh chu nên có thể thao tác sẽ chậm, tăng tốc độ phát để có trải nghiệm tốt hơn.
- Video Final_user.mp4 để tránh gây nhầm lẫn nên chúng em đã chú thích :
	+ Người dùng giáo viên sử dụng trình duyệt có phần tabs : màu xanh ngọc, email: tea@tea
	+ Người dùng sinh viên sử dùng trình duyệt có phần tabs : màu đen      , email: stu@stu
- Cảm ơn cô vì đã đọc, chúc cô và gia đình nhiều sức khỏe !

<?php 
echo "<h1>Phòng chưa được tạo!</h1>";
echo "<h1>Hãy quay lại sau!</h1>";
?>
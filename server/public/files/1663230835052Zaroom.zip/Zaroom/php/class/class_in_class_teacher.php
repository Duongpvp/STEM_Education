<?php
session_start();
include ('../../includes/config.php');
if (isset($_GET['idClass'])) {
    $_SESSION['idClass'] = $_GET['idClass'];
    $_SESSION['nameClass'] = $_GET['nameCla'];
}
$query = mysqli_query($conn, "SELECT * FROM users WHERE id='{$_SESSION['SESSION_ID']}'");
if (mysqli_num_rows($query) > 0) {
    $row = mysqli_fetch_assoc($query);
    $id_user = $row['id'];
    $email = $row['email'];
}
$sql = "SELECT * FROM `relation` WHERE r_to = '$email' AND request = 1";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">

<body>

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <title><?php echo $_SESSION['nameClass']; ?></title>
        <link rel="stylesheet" href="../../chat_dversion/css/style.css" />
        <link rel="stylesheet" href="./style.css" />

        <style>
            .img-bt {
                width: 9%;
                height: 30px;
                margin-top: 7%;

            }

            .thea {
                height: 60px;
                border: 1px solid;
                border-radius: 5px;
                font-size: 30px;
                padding: 3%;
                color: black;
                background-color: #E6E6E6;
            }

            .div-bt {
                width: 18%;
                height: 50px;
                margin-left: 1%;
            }

            .bt {
                padding: 2%;
            }

            a.thea:hover,
            a.thea:focus {
                background-color: green;
            }
        </style>
    </head>
    <div class="class-header">
        <ul style="display:flex;">
            <li><button class="button" onclick="window.location='./class_teacher.php';"><span>Trở về</span></button></li>
            <li id="li"><span class="nameCla"><?php echo $_SESSION['nameClass']; ?> </span> </li>
        </ul>
    </div>
    <div class='div-bt'>
        <a class="thea" href="./post.php"><img src="../../images/homework.png" alt="image" class="img-bt"><span class="bt">Thêm bài tập</span></a>
    </div>
</body>

</html>
<?php
echo "<div class='main'>
     ";
$result = $conn->query("SELECT * FROM `class`, `ex_class`,`exercise` WHERE ex_class.id_class_r=$_SESSION[idClass] 
            AND exercise.id_ex=ex_class.id_ex_r AND ex_class.id_class_r=class.id_class");
echo "<table class='post-table'>
    
            <td id='list'> 
            <h3 id='name-list'><b>Danh sách bài tập</b><br></h3>";
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "
                 <h4><b>$row[title_ex]</b></h4>";
    }
}

echo " </td>
            <td style='width:80% ;border-left:solid; border-color: gray;'>
    ";
// echo "<div class='post'>";
$result = $conn->query("SELECT * FROM `class`, `ex_class`,`exercise` WHERE ex_class.id_class_r=$_SESSION[idClass] 
            AND exercise.id_ex=ex_class.id_ex_r AND ex_class.id_class_r=class.id_class");
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<div class='main-post'>
                    <div class='title-post'>
                        <a href='detail_exercise.php?idPost=$row[id_ex]'><h3><b>$row[title_ex]</b></h3></a>
                    </div>
                    <div class='content-post'>
                        $row[content_ex]
                    </div>
                </div>
            
            ";
    }
    //echo "</div>
    echo "</td>";
    echo "</div></table>";
}
?>
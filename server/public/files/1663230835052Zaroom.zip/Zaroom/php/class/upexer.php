<?php
    include ('../../includes/config.php');
    echo "Test";
?>
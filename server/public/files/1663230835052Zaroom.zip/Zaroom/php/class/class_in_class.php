<?php
session_start();
include ('../../includes/config.php');
if(isset($_GET['idClass'])){
$_SESSION['idClass'] = $_GET['idClass'];
$_SESSION['nameClass'] = $_GET['nameCla'];}
$query = mysqli_query($conn, "SELECT * FROM users WHERE id='{$_SESSION['SESSION_ID']}'");
if (mysqli_num_rows($query) > 0) {
    $row = mysqli_fetch_assoc($query);
    $id_user = $row['id'];
    $email = $row['email'];
}
$sql = "SELECT * FROM `relation` WHERE r_to = '$email' AND request = 1";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">

<body >

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <title><?php echo $_SESSION['nameClass']; ?></title>
        <link rel="stylesheet" href="../../chat_dversion/css/style.css" />
        <link rel="stylesheet" href="./style.css" />

        <style>
            .options{
                font-weight: bolder;
                text-align: center;
            }

            .options span{
                padding: 0.5%;
                font-size: 20px;
                border-radius: 10px;
            }
            .options a{
                text-decoration: none;
                color:black;
            }
            .options span:hover{
                background-color: azure;
            }
            img{
                width: 20px;
                height: 20px;
            }

        </style>
        
    </head>
    <div class="class-header" style="margin-bottom:2%;">
        <ul style="display:flex;">   
            <li><button class="button" onclick="window.location='./class.php';"><span>Trở về</span></button></li>
            <li id="li"><span class="nameCla"><?php echo $_SESSION['nameClass']; ?> </span> </li>
        </ul>
    </div>
    <div class='options'>
        <a href="./class_in_class.php"><span style="text-decoration-line:underline;">Tin tức</span></a>
        <a href="./everyone.php"><span>Mọi người</span></a>
    </div>

</body>

</html>
<?php 
     echo "<div class='main'>
     ";
    $result = $conn->query("SELECT * FROM `class`, `ex_class`,`exercise` WHERE ex_class.id_class_r=$_SESSION[idClass] 
            AND exercise.id_ex=ex_class.id_ex_r AND ex_class.id_class_r=class.id_class");
    echo "<table class='post-table'>
    
            <td id='list'> 
            <h3 id='name-list'><b>Danh sách bài tập</b><br></h3>";
            if($result->num_rows > 0){
                while($row=$result->fetch_assoc()){
                    echo"
                 <h4><b>$row[title_ex]</b></h4>";
                }
            }
           
           echo " </td>
            <td style='width:80% ;border-left:solid; border-color: gray;'>
    ";
   // echo "<div class='post'>";
   $result = $conn->query("SELECT * FROM `class`, `ex_class`,`exercise` WHERE ex_class.id_class_r=$_SESSION[idClass] 
            AND exercise.id_ex=ex_class.id_ex_r AND ex_class.id_class_r=class.id_class");
    if($result->num_rows > 0){
        while($row=$result->fetch_assoc()){
            echo "<div class='main-post'>
                    <div class='title-post'>
                        <a href='detail_exercise.php?idPost=$row[id_ex]'><h3><b>$row[title_ex]</b></h3></a>
                    </div>
                    <div class='content-post'>
                        $row[content_ex]
                    </div>
                    <div class='file-post'>";
                        
                        $typePath = pathinfo($row['file_ex'],PATHINFO_EXTENSION);
                        switch ($typePath){
                            case "doc":
                                echo "<a href='class.php'><img src='./img/doc.png'> $row[file_ex]</a>";
                                break;
                            case "docx":
                                echo "<img src='./img/doc.png'> $row[file_ex]";
                                break;
                            case "xlsx":
                                echo "<img src='./img/excel.jpg'> $row[file_ex]";
                                break;
                            case "jpg":
                                echo "<img src='./img/image.jpg'> $row[file_ex]";
                                break;
                            case "png":
                                echo "<img src='./img/image.jpg'> $row[file_ex]";
                                break;
                            case "zip":
                                echo "<img src='./img/zip.jpg'> $row[file_ex]";
                                break;
                            case "rar":
                                echo "<img src='./img/zip.jpg'> $row[file_ex]";
                                break;
                            case "pdf":
                                echo "<img src='./img/pdf.png'> $row[file_ex]";
                                break;
                            default:
                                echo "<img src='./img/default.png'> $row[file_ex]";
                            
                        }
                    echo "</div>
                </div>
            
            ";
        }
        //echo "</div>
        echo"</td>";
        echo "</div></table>";
    }
?>
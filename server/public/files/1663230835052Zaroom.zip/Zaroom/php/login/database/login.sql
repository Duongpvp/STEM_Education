-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th3 24, 2022 lúc 10:11 AM
-- Phiên bản máy phục vụ: 10.4.18-MariaDB
-- Phiên bản PHP: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `login`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `class`
--

CREATE TABLE `class` (
  `id_class` int(3) NOT NULL,
  `name_class` varchar(30) NOT NULL,
  `time` datetime NOT NULL,
  `code` varchar(6) NOT NULL,
  `teacher` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `class`
--

INSERT INTO `class` (`id_class`, `name_class`, `time`, `code`, `teacher`) VALUES
(1, '1', '2022-03-18 02:49:16', '', ''),
(2, 'ATHT', '2022-03-18 02:49:55', '', ''),
(3, 'ANM', '2022-03-18 02:49:55', '', ''),
(4, '4', '2022-03-18 02:50:16', '', ''),
(5, 'LTW', '2022-03-18 02:50:16', '', '');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `class_user`
--

CREATE TABLE `class_user` (
  `id_class` int(3) NOT NULL,
  `id_user` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `class_user`
--

INSERT INTO `class_user` (`id_class`, `id_user`) VALUES
(5, 11),
(1, 12),
(3, 12),
(1, 13),
(4, 13),
(5, 14),
(2, 14),
(1, 11),
(4, 11);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `messages`
--

CREATE TABLE `messages` (
  `id_msg` int(3) NOT NULL,
  `body` longtext NOT NULL,
  `user_from` text NOT NULL,
  `date_sent` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Đang đổ dữ liệu cho bảng `messages`
--

INSERT INTO `messages` (`id_msg`, `body`, `user_from`, `date_sent`) VALUES
(13, 'Tao ten la', 'duong891109@gmail.com', '2022-03-22 12:34:52'),
(14, 'fhdfhdfhdfh', 'moi', '2022-03-22 07:47:46'),
(15, 'dgjdhfgjidgod', 'luanlt632000@gmail.com', '2022-03-22 07:57:33'),
(16, 'hello!', 'luanlt632000@gmail.com', '2022-03-22 08:00:07'),
(17, 'ghdfjkngdfkjghdo', '1', '2022-03-22 08:00:40'),
(18, 'sdfsd', '2', '2022-03-22 08:21:57'),
(19, 'alo', 'luanlt632000@gmail.com', '0000-00-00 00:00:00'),
(20, 'uraaa', 'luanlt632000@gmail.com', '0000-00-00 00:00:00'),
(21, 'aaaaaaa', 'luanlt632000@gmail.com', '2022-03-22 14:27:50'),
(22, 'Hello!!!', 'luanlt632000@gmail.com', '2022-03-22 14:28:46'),
(23, 'Hello!', 'luanlt632000@gmail.com', '2022-03-22 14:29:54'),
(24, 'lmao', 'luanlt632000@gmail.com', '2022-03-22 14:31:04'),
(25, 'bruh', 'luanlt632000@gmail.com', '2022-03-22 14:31:19'),
(26, 'lmao lmao bruh', 'luanlt632000@gmail.com', '2022-03-22 14:31:49'),
(27, 'fuck', 'luanlt632000@gmail.com', '2022-03-22 14:59:49'),
(28, 'fuckl', 'luanlt632000@gmail.com', '2022-03-22 15:04:30'),
(29, 'bsdjhf', 'luanlt632000@gmail.com', '2022-03-22 15:07:48'),
(30, 'gdfg', 'luanlt632000@gmail.com', '2022-03-22 15:21:03'),
(31, 'àasgdf', 'dfher', '2022-03-22 09:21:11'),
(32, 'dsfsdf', 'luanlt632000@gmail.com', '2022-03-22 15:32:16'),
(33, 'fghfhfhg', 'dat', '2022-03-22 09:32:58'),
(34, 'gdfhfghf', 'aaaa', '2022-03-22 09:39:50'),
(35, 'hello', 'Dat09', '2022-03-22 09:54:02'),
(36, 'hello', 'luanb1807573@student.ctu.edu.vn', '2022-03-22 15:57:40'),
(37, 'Chao bạn bên kia nha', 'luanb1807573@student.ctu.edu.vn', '2022-03-22 15:58:11'),
(38, 'hi', 'luanlt632000@gmail.com', '2022-03-22 15:58:20'),
(39, 'ád', 'luanlt632000@gmail.com', '2022-03-22 15:59:32'),
(40, 'áda', 'luanlt632000@gmail.com', '2022-03-22 16:00:23'),
(41, 'jsdfio', 'luanb1807573@student.ctu.edu.vn', '2022-03-22 16:01:19'),
(42, 'sdfsd', 'luanb1807573@student.ctu.edu.vn', '2022-03-22 16:01:55');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `relation`
--

CREATE TABLE `relation` (
  `id` int(3) NOT NULL,
  `r_from` varchar(50) NOT NULL,
  `r_to` varchar(50) NOT NULL,
  `request` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `relation`
--

INSERT INTO `relation` (`id`, `r_from`, `r_to`, `request`) VALUES
(24, 'luanlt632000@gmail.com', 'luanb1807573@student.ctu.edu.vn', 0),
(26, '2', 'luanlt632000@gmail.com', 0),
(27, '4', 'luanlt632000@gmail.com', 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `room`
--

CREATE TABLE `room` (
  `id_room` int(5) NOT NULL,
  `date_create` datetime NOT NULL,
  `name_room` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `room`
--

INSERT INTO `room` (`id_room`, `date_create`, `name_room`) VALUES
(1, '2022-03-24 08:12:14', ''),
(2, '2022-03-24 08:12:32', ''),
(3, '2022-03-24 08:41:50', 'luanlt632000@gmail.comj2'),
(4, '2022-03-24 08:47:44', '2luanlt632000@gmail.com'),
(5, '2022-03-24 15:22:12', 'luanlt632000@gmail.com2'),
(7, '2022-03-24 15:24:40', 'luanlt632000@gmail.com2'),
(13, '2022-03-24 09:32:01', 'luanb1807573@student.ctu.edu.vnluanlt632000@gmail.com');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `room_chat`
--

CREATE TABLE `room_chat` (
  `id_room` int(11) NOT NULL,
  `id_msg` int(11) NOT NULL,
  `id_user` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `room_chat`
--

INSERT INTO `room_chat` (`id_room`, `id_msg`, `id_user`) VALUES
(2, 21, 8),
(1, 19, 12),
(3, 21, 8),
(3, 19, 12),
(4, 25, 8);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `code` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `code`) VALUES
(8, 'fds', 'luanlt632000@gmail.com', 'c4ca4238a0b923820dcc509a6f75849b', ''),
(10, 'ád', 'luanb1807573@student.ctu.edu.vn', 'c4ca4238a0b923820dcc509a6f75849b', ''),
(11, '1', '1@1', 'c4ca4238a0b923820dcc509a6f75849b', ''),
(12, '2', '2', '', ''),
(13, '3', '3', '', ''),
(14, '4', '4', '', '');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`id_class`);

--
-- Chỉ mục cho bảng `class_user`
--
ALTER TABLE `class_user`
  ADD KEY `classes` (`id_class`),
  ADD KEY `users` (`id_user`);

--
-- Chỉ mục cho bảng `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id_msg`);

--
-- Chỉ mục cho bảng `relation`
--
ALTER TABLE `relation`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`id_room`);

--
-- Chỉ mục cho bảng `room_chat`
--
ALTER TABLE `room_chat`
  ADD KEY `id_user` (`id_user`),
  ADD KEY `id_msg` (`id_msg`),
  ADD KEY `id_room` (`id_room`);

--
-- Chỉ mục cho bảng `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `class`
--
ALTER TABLE `class`
  MODIFY `id_class` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT cho bảng `messages`
--
ALTER TABLE `messages`
  MODIFY `id_msg` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT cho bảng `relation`
--
ALTER TABLE `relation`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT cho bảng `room`
--
ALTER TABLE `room`
  MODIFY `id_room` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT cho bảng `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `class_user`
--
ALTER TABLE `class_user`
  ADD CONSTRAINT `classes` FOREIGN KEY (`id_class`) REFERENCES `class` (`id_class`),
  ADD CONSTRAINT `users` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`);

--
-- Các ràng buộc cho bảng `room_chat`
--
ALTER TABLE `room_chat`
  ADD CONSTRAINT `room_chat_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `room_chat_ibfk_2` FOREIGN KEY (`id_msg`) REFERENCES `messages` (`id_msg`),
  ADD CONSTRAINT `room_chat_ibfk_3` FOREIGN KEY (`id_room`) REFERENCES `room` (`id_room`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

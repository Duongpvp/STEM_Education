<?php
    //Import PHPMailer classes into the global namespace
    //These must be at the top of your script, not inside a function
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\SMTP;
    use PHPMailer\PHPMailer\Exception;

    session_start();
    if (isset($_SESSION['SESSION_EMAIL'])) {
        header("Location: index.php");
        die();
    }

    //Load Composer's autoloader
    require 'vendor/autoload.php';
    include ('../../includes/config.php');
    $msg = "";

    if (isset($_POST['submit'])) {
        $name = mysqli_real_escape_string($conn, $_POST['name']);
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $password = mysqli_real_escape_string($conn, md5($_POST['password']));
        $password_check = mysqli_real_escape_string($conn, ($_POST['password']));
        $confirm_password = mysqli_real_escape_string($conn, md5($_POST['confirm-password']));
        $code = mysqli_real_escape_string($conn, md5(rand()));

        $partten = "/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{6,32}$/";

        if (mysqli_num_rows(mysqli_query($conn, "SELECT * FROM users WHERE email='{$email}'")) > 0) {
            $msg = "<div class='alert alert-danger'>{$email} - Mail đã tồn tại.</div>";
        } else {
            if ($password === $confirm_password) {
                if(!preg_match($partten, $password_check, $matchs)){
                    $msg = "<div class='alert alert-danger'>Mật khẩu không hợp lệ.</div>";
                } else {
                    $sql = "INSERT INTO users (name, email, password, code) VALUES ('{$name}', '{$email}', '{$password}', '{$code}')";
                    $result = mysqli_query($conn, $sql);
                
                    if ($result) {
                        echo "<div style='display: none;'>";
                        //Create an instance; passing `true` enables exceptions
                        $mail = new PHPMailer(true);

                        try {
                            //Server settings
                            $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
                            $mail->isSMTP();                                            //Send using SMTP
                            $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
                            $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
                            $mail->Username   = 'duong891109@gmail.com';                     //SMTP username
                            $mail->Password   = 'DRDq2cz6';                               //SMTP password
                            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
                            $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

                            //Recipients
                            $mail->setFrom('duong891109@gmail.com', 'Duongdepzai');
                            $mail->addAddress($email);

                            //Content
                            $mail->isHTML(true);                                  //Set email format to HTML
                            $mail->Subject = 'no reply';
                            $mail->Body    = 'Đây là đường dẫn xác nhận được gửi từ người đẹp trai nhất thế giới Mr.Phi Dương : <b><a href="http://localhost/Zaroom/php/login/?verification='.$code.'">http://localhost/Zaroom/php/login/?verification='.$code.'</a></b>';

                            $mail->send();
                            echo 'Tin nhắn đã được gửi';
                        } catch (Exception $e) {
                            echo "Đã xảy ra lỗi trong quá trình gửi. Mailer Error: {$mail->ErrorInfo}";
                        }
                        echo "</div>";
                        $msg = "<div class='alert alert-info'>Chúng tôi đã gửi mã xác nhận đến email của bạn.</div>";
                    } else {
                        $msg = "<div class='alert alert-danger'>Có lỗi xảy ra.</div>";
                    }
                }
            } else {
                $msg = "<div class='alert alert-danger'>Mật khẩu không trùng khớp</div>";
            }
        }
    }
?>

<!DOCTYPE html>
<html lang="zxx">

<head>
    <title>Login Form - Đăng ký</title>
    <!-- Meta tag Keywords -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="UTF-8" />
    <meta name="keywords"
        content="Login Form" />
    <!-- //Meta tag Keywords -->

    <link href="//fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">

    <!--/Style-CSS -->
    <link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
    <!--//Style-CSS -->
    <link rel="stylesheet" href="../../css/login.css">
    


    <script src="https://kit.fontawesome.com/af562a2a63.js" crossorigin="anonymous"></script>

</head>

<body>

    <!-- form section start -->
    <section class="w3l-mockup-form">
        <div class="container">
            <!-- /form -->
            <div class="workinghny-form-grid">
                <div class="main-mockup">
                    <div class="content-wthree">
                        <h2 class="title">Đăng ký tài khoản</h2>
                        <p>Zaroom Website hỗ trợ học tập miễn phí hàng đầu Việt Nam </p>
                        <?php echo $msg; ?>
                        <form action="" method="post">
                            <input type="text" class="name" name="name" placeholder="Nhập tên tài khoản" value="<?php if (isset($_POST['submit'])) { echo $name; } ?>" required>
                            <input type="email" class="email" name="email" placeholder="Nhập Email" value="<?php if (isset($_POST['submit'])) { echo $email; } ?>" required>
                            <input type="password" class="password" name="password" placeholder="Nhập mật khẩu" required>
                            <input type="password" class="confirm-password" name="confirm-password" placeholder="Nhập lại mật khẩu" required>
                            <button name="submit" class="btn" type="submit">Đăng ký</button>
                        </form>
                        <div class="social-icons">
                            <p>Bạn đã có tài khoản : <a href="index.php">Đăng nhập</a>.</p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- //form -->
        </div>
    </section>
    <!-- //form section start -->

    <script src="js/jquery.min.js"></script>
    <script>
        $(document).ready(function (c) {
            $('.alert-close').on('click', function (c) {
                $('.main-mockup').fadeOut('slow', function (c) {
                    $('.main-mockup').remove();
                });
            });
        });
    </script>

</body>

</html>